# Paper A (JACT) pipeline

Reproducible analysis chain for the multiscale TDA manuscript. Analysis modules
are vendored under the paper folder (`../01_data`, `../02_tda_core`,
`../03_football_analysis`); summaries are written to `outputs/` for LaTeX sync.

## Prerequisites

- Python 3.10+ (`pip install -r ../requirements.txt`)
- SkillCorner Open Data at `../01_data/opendata/data/` (see `../01_data/README.md`)
- Run via `run_all.sh` (sets working directory to the paper root)

## Sampling profiles (`config.yaml`)

| Profile | Frames | Used for |
|---------|--------|----------|
| `uniform_150` | 150 uniformly spaced complete frames | Paper A Tables (`tab:h1single`, `tab:h1multi`, sensitivity, complementarity) |
| `cutoff_sweep_windows` | 58 windows × 4 epoch lengths | `tab:regimes`, stability scores |
| `temporal_2min` | 2-min non-overlapping windows | Grant-only temporal analysis (not headline Paper A tables) |

## Run order

```bash
cd pipeline
chmod +x run_all.sh
./run_all.sh
```

Individual steps:

```bash
python3 steps/01_primary_uniform.py
python3 steps/02_cutoff_sweep.py
python3 steps/03_multi_match.py
python3 steps/05_event_validity.py
python3 steps/04_complementarity.py
python3 steps/06_figures.py
python3 lib/build_numbers.py
python3 sync_to_paper.py
```

## Outputs (committed)

- `outputs/manifest.json` — SHA-256 hashes, git commit, timestamp
- `outputs/numbers.json` — headline scalars for sync
- `outputs/regime_summary.csv`
- `outputs/uniform_150/uniform_summary.json`
- `outputs/aggregate_stats.json`
- `outputs/complementarity/complementarity_tests.json`
- `../figures/fig2_cycle_geometry.pdf`
